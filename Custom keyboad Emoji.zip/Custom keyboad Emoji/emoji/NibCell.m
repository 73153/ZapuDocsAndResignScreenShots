//
//  NibCell.m
//  CustomKeyboard
//
//  Created by Santosh on 11/06/2016.
//  Copyright © 2016 Sky. All rights reserved.
//

#import "NibCell.h"

@implementation NibCell

-(void)awakeFromNib
{
    NSLog(@"sasaa");
}
@end
