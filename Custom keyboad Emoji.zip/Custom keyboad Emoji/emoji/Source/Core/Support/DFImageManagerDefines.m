// The MIT License (MIT)
//
// Copyright (c) 2015 Alexander Grebenyuk (github.com/kean).

#import "DFImageManagerDefines.h"

CGSize const DFImageMaximumSize = { FLT_MAX, FLT_MAX };

NSString *const DFImageManagerErrorDomain = @"DFImageManagerErrorDomain";
