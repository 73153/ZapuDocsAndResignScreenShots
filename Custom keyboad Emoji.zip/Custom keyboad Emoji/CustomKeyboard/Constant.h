//
//  Constant.h
//  CustomKeyboard
//
//  Created by Sky on 4/4/15.
//  Copyright (c) 2015 Sky. All rights reserved.
//

#ifndef CustomKeyboard_Constant_h
#define CustomKeyboard_Constant_h

#define FUNKYFRESH_IAP @"com.deepfriedproductions.rampagemoji.fullversion"
#define GUNGHO_IAP     @"com.sinkfoot.gungho"
#define AVANTGARDE_IAP @"com.sinkfoot.avantgarde"
#define CRAYCRAY_IAP   @"com.sinkfoot.craycray"

#define IAPNOTIFICATION @"IAPRESULT"
#define IAPRESTORENOTIFICATION @"RESTORERESULT"
#endif

