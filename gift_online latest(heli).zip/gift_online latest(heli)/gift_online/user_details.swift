//
//  user_details.swift
//  Delicious
//
//  Created by nilomi on 2/10/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

#if os(iOS)
    import UIKit
#else
    import AppKit
#endif


class user_details:SQLTable {
    var user_id = -1
    var username = ""
     var emailid = ""
     var password = ""
    var address = ""
    var phn_no = -1
}
