//
//  CollectionViewCell.swift
//  SwiftDemo
//
//  Created by heli on 1/18/17.
//  Copyright © 2016 zaptech. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet var imgview: UIImageView!
    
    @IBOutlet weak var product_name: UILabel!
    
    @IBOutlet weak var img_veg_nonveg: UIImageView!
    @IBOutlet weak var product_type: UILabel!
    @IBOutlet weak var price: UILabel!
   }
