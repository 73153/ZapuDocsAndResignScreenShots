//
//  MultipleSelectionCollVC.swift
//  MultipleImageSelectionCollectionView
//
//  Created by heli on 1/18/17.
//  Copyright © 2017 com.zaptechsolution. All rights reserved.
//

import UIKit

class MultipleSelectionCollVC: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate
 {
    
    
    
 var viewimageselected:NSMutableArray = NSMutableArray ()
     var displayArry = [product_details]()
    override func viewDidLoad() {
        super.viewDidLoad()
   // view.backgroundColor = UIColor(patternImage: UIImage(named: "image")!)

        // Do any additional setup after loading the view.
    }
    let reuseIdentifier = "Cell3"
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return displayArry.count
    }
    
    // make a cell for each cell index path
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        // get a reference to our storyboard cell
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath as IndexPath) as! MultipleSelectionColCell
        
        let task = displayArry[indexPath.row]
        cell.imgViewMultiSelect.image = UIImage(named:task.image)!
        cell.lbl_name.text = task.product_name
        cell.lbl_type.text = task.type
        cell.lbl_price.text = task.price

       // cell.backgroundColor = UIColor(patternImage: UIImage(named: "image")!)
       // = (named: displayArry[indexPath.item] as? UIImage)
        
      // cell.backgroundColor = UIColor.init(red: 135, green: 206, blue: 250, alpha: 1)
        return cell
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = collectionView.cellForItem(at: indexPath)
        if cell?.isSelected == true {
            cell?.backgroundColor = UIColor.lightGray
            viewimageselected.add(displayArry[indexPath.row])
        }
        
    //  cell?.backgroundColor = UIColor(patternImage: UIImage(named: "image")!)
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        
        let objSomeViewController = storyBoard.instantiateViewController(withIdentifier: "singleselecteddisplay") as! singleselecteddisplay
        objSomeViewController.displayArry = viewimageselected
        self.navigationController?.pushViewController(objSomeViewController, animated: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
