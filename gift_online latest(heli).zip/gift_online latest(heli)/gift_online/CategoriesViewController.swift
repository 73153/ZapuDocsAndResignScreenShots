//
//  CategoriesViewController.swift
//  Delicious
//
//  Created by heli on 2/15/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

import UIKit

class CategoriesViewController: UIViewController ,UICollectionViewDataSource,UICollectionViewDelegate{
    
    
    var x=0
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    var  arydata = [product_details]()
    var selectedCell = [product_details]()

    @IBOutlet var collectionview: UICollectionView!
    
      let cellReuseIdentifier = "CellColl"
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "CATEGORIES"
        self.setNavigationBarItem()
        self.navigationItem.title=appDelegate.filter
       
                collectionview.register(CollectionCell.self, forCellWithReuseIdentifier:cellReuseIdentifier)

        

        self.GetDataFromDataBase()
        
        collectionview.dataSource = self
        collectionview.delegate = self

        
        let rightAddBarButtonItem:UIBarButtonItem = UIBarButtonItem(title: "Next", style: UIBarButtonItemStyle.plain, target: self, action: #selector(CategoriesViewController.addTapped))
        
        self.navigationItem.setRightBarButtonItems([rightAddBarButtonItem], animated: true)
        let longGesture = UILongPressGestureRecognizer(target: self, action: #selector(CategoriesViewController.longTap))
        
       collectionview.addGestureRecognizer(longGesture)
    }

    func longTap(sender : UIGestureRecognizer){
        print("Long tap")
        if sender.state == .ended {
            print("UIGestureRecognizerStateEnded")
            //Do Whatever You want on End of Gesture
            if x==0 {
                
                collectionview.allowsMultipleSelection = true
                
                x=1;
            }
            else {
                collectionview.allowsMultipleSelection = false
            
                selectedCell = [product_details]()
                x=0;
            }
            
        }
        else if sender.state == .began {
            print("UIGestureRecognizerStateBegan.")
            //Do Whatever You want on Began of Gesture
        }
    }
    
    
    func addTapped (sender:UIButton) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        
        let objSomeViewController = storyBoard.instantiateViewController(withIdentifier: "CollectionViewController") as! CollectionViewController
        objSomeViewController.Places = (selectedCell as NSArray) as! [product_details]
        self.navigationController?.pushViewController(objSomeViewController, animated: true)
        
    }
    

    func setNavigationBarItem() {
        self.navigationController?.navigationBar.titleTextAttributes =
            [NSForegroundColorAttributeName: UIColor.yellow]
        self.addLeftBarButtonWithImage((UIImage(named:"menu_icon")?.withRenderingMode(.alwaysOriginal))!)
        self.addRightBarButtonWithImage((UIImage(named:"search")?.withRenderingMode(.alwaysOriginal))!)
        self.slideMenuController()?.removeLeftGestures()
        self.slideMenuController()?.removeRightGestures()
        self.slideMenuController()?.addLeftGestures()
        self.slideMenuController()?.addRightGestures()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
        // MARK:- Editing
    
    override func setEditing(_ editing: Bool, animated: Bool) {
        super.setEditing(editing, animated: animated)
        collectionview?.allowsMultipleSelection = editing
        
    }

    
    internal func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return arydata.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        // get a reference to our storyboard cell
        let Cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellReuseIdentifier, for: indexPath as IndexPath) as! CollectionCell
        let task = arydata[indexPath.row]
        Cell.imageView.image = UIImage(named:task.image)!
       
        Cell.label.text = task.product_name
        Cell.backgroundColor = UIColor.init(red: 135, green: 206, blue: 250, alpha: 1)
        return Cell
    }
    
     func numberOfSections(in collectionView: UICollectionView) -> Int
    {
        return 1
    }
    
    private func collectionView(_ collectionView: UICollectionView, didSelectRowAt indexPath: IndexPath) {
                selectedCell = [arydata[indexPath.row]]
                let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        
                let objSomeViewController = storyBoard.instantiateViewController(withIdentifier: "CollectionViewController") as! CollectionViewController
                objSomeViewController.Places = (selectedCell as NSArray) as! [product_details]
                self.navigationController?.pushViewController(objSomeViewController, animated: true)
        
    }

    
       func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let Cell = collectionView.cellForItem(at: indexPath)
        if Cell?.isSelected == true {
            Cell?.backgroundColor = UIColor.lightGray
            selectedCell = [arydata[indexPath.row]]
            
            // selectedCell.add(Places[indexPath.row])
        }
        
    }

    func GetDataFromDataBase() {
        
        let db = SQLiteDB.sharedInstance
        
        //        arydata = product_details.rows(order:"product_id ASC") as! [product_details]
        arydata = product_details.rows(filter:"subtype = '\(appDelegate.filter)'",filter1:"categories= '\(appDelegate.category)'",order:"product_id ASC") as! [product_details]
        
        let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent("bakerydb")
        print("doc path\(fileURL)")
    }


      
    
}
