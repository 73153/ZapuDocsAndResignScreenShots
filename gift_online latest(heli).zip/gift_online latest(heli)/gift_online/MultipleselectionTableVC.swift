//
//  MultipleselectionTableVC.swift
//  MultipleImageSelectionCollectionView
//
//  Created by heli on 1/18/17.
//  Copyright © 2017 com.zaptechsolution. All rights reserved.
//

import UIKit

class MultipleselectionTableVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    let cellReuseIdentifier = "Cell4"
    var displayArry:NSArray = NSArray()
    

    @IBOutlet var tblView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title="Selected Images"
        tblView.register(UITableViewCell.self, forCellReuseIdentifier: cellReuseIdentifier)
        
        // let rightAddBarButtonItem:UIBarButtonItem = UIBarButtonItem(title: "Next", style: UIBarButtonItemStyle.plain, target: self, action: #selector(tableViewController.addTapped))
        
        // self.navigationItem.setRightBarButtonItems([rightAddBarButtonItem], animated: true)
        // tblView.backgroundColor = UIColor(patternImage: UIImage(named: "bg")!)
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return displayArry.count
    }
    
    // create a cell for each table view row
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // create a new cell if needed or reuse an old one
        let cell:UITableViewCell = tblView.dequeueReusableCell(withIdentifier: cellReuseIdentifier) as UITableViewCell!
        
        // let object = displayArry[indexPath.row]
        // set the text from the data model
        cell.imageView?.image = (named: displayArry[indexPath.row] as? UIImage)
        // cell.backgroundColor = UIColor(patternImage: UIImage(named: "bg")!)
    
        //  cell.imageView?.image = UIImage(named: object["image"]!)
        
        return cell
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
