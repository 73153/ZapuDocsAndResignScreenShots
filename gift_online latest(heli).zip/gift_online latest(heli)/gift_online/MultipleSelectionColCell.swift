//
//  MultipleSelectionColCell.swift
//  SwiftDemo
//
//  Created by heli on 1/18/17.
//  Copyright © 2017 zaptech. All rights reserved.
//

import UIKit

class MultipleSelectionColCell: UICollectionViewCell{
    
    @IBOutlet var imgViewMultiSelect: UIImageView!
    
    @IBOutlet weak var view_cell: UILabel!
    @IBOutlet weak var img_veg_nonveg: UIImageView!
    @IBOutlet weak var lbl_type: UILabel!
    @IBOutlet weak var lbl_name: UILabel!
    @IBOutlet weak var lbl_price: UILabel!
}
