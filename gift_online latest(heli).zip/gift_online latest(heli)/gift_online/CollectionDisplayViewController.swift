//
//  CollectionDisplayViewController.swift
//  MultipleImageSelectionCollectionView
//
//  Created by heli on 1/18/17.
//  Copyright © 2017 com.zaptechsolution. All rights reserved.
//

import UIKit

class CollectionDisplayViewController: UIViewController {

    @IBOutlet var imgview: UIImageView!
    var imgStr : UIImage?
    override func viewDidLoad() {
      //  view.backgroundColor = UIColor(patternImage: UIImage(named: "image")!)
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
