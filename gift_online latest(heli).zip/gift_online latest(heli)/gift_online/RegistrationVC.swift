//
//  RegistrationVC.swift
//  gift_online
//
//  Created by heli on 2/8/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

import UIKit

class RegistrationVC: UIViewController {

    @IBOutlet var lblfirstname: UILabel!
    @IBOutlet var txtfirstname: UITextField!
    @IBOutlet var lbllastname: UILabel!
    @IBOutlet var txtlastname: UITextField!
    
    @IBOutlet var lblemail: UILabel!
    @IBOutlet var txtEmail: UITextField!
    
    @IBOutlet var lblPassword: UILabel!
    
    @IBOutlet var txtpassword: UITextField!
    
    @IBOutlet var lblCpass: UILabel!
    @IBOutlet var txtCpass: UITextField!
    func setNavigationBarItem() {
        self.navigationController?.navigationBar.titleTextAttributes =
            [NSForegroundColorAttributeName: UIColor.yellow]
        self.addLeftBarButtonWithImage((UIImage(named:"menu_icon")?.withRenderingMode(.alwaysOriginal))!)
        self.addRightBarButtonWithImage((UIImage(named:"search")?.withRenderingMode(.alwaysOriginal))!)
        self.slideMenuController()?.removeLeftGestures()
        self.slideMenuController()?.removeRightGestures()
        self.slideMenuController()?.addLeftGestures()
        self.slideMenuController()?.addRightGestures()
    }

    @IBAction func btnSubmit(_ sender: AnyObject) {
            if(txtfirstname.text == nil){
            var alert : UIAlertView = UIAlertView(title: "Oops!", message: "Please enter your first name.",delegate: nil, cancelButtonTitle: "OK")
            alert.show()
            
        }else if (txtlastname.text == nil){
            var alert : UIAlertView = UIAlertView(title: "Oops!", message: "Please enter your last name.",
                                                  delegate: nil, cancelButtonTitle: "OK")
            alert.show()
            
        }else if (txtEmail.text == nil){
            var alert : UIAlertView = UIAlertView(title: "Oops!", message: "Please enter your email id.",
                                                  delegate: nil, cancelButtonTitle: "OK")
            alert.show()
            
        }else if !isValidEmail(testStr: txtEmail.text!){
            var alert : UIAlertView = UIAlertView(title: "Oops!", message: "Please enter your correct email id.",
                                                  delegate: nil, cancelButtonTitle: "OK")
            alert.show()
            
        }else if (txtpassword.text == nil){
            var alert : UIAlertView = UIAlertView(title: "Oops!", message: "Please enter your password.",
                                                  delegate: nil, cancelButtonTitle: "OK")
            alert.show()
            
        }else if (txtCpass.text != txtpassword.text){
            var alert : UIAlertView = UIAlertView(title: "Oops!", message: "Confirmed password not matched please try again.",
                                                  delegate: nil, cancelButtonTitle: "OK")
            alert.show()
            
        }else{
            var alert : UIAlertView = UIAlertView(title: "User Registration!", message: "Your Registration is successfully.",
                                                  delegate: nil, cancelButtonTitle: "OK")
            alert.show()
            
            let viewControllers: [UIViewController] = self.navigationController!.viewControllers as [UIViewController];
            self.navigationController!.popToViewController(viewControllers[viewControllers.count - 2], animated: true);
        
        
    }
        
        func viewDidLoad() {
            super.viewDidLoad()
           setNavigationBarItem()
            // Do any additional setup after loading the view.
        }
        

        func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
        }
    }
        func textFieldShouldReturn(textField: UITextField) -> Bool
        {
            if(textField.returnKeyType == UIReturnKeyType.done)
            {
                textField .resignFirstResponder()
            }
            else
            {
                let txtFld : UITextField? = self.view.viewWithTag(textField.tag + 1) as? UITextField;
                txtFld?.becomeFirstResponder()
            }
            return true
        }
        
        func isValidEmail(testStr:String) -> Bool {
            let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
            
            let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
            let result = emailTest.evaluate(with: testStr)
            return result
        }


    
    

}
extension RegistrationVC : SlideMenuControllerDelegate {
    func leftWillOpen() {
        print("SlideMenuControllerDelegate: leftWillOpen")
    }
    func leftDidOpen() {
        print("SlideMenuControllerDelegate: leftDidOpen")
    }
    func leftWillClose() {
        print("SlideMenuControllerDelegate: leftWillClose")
    }
    func leftDidClose() {
        print("SlideMenuControllerDelegate: leftDidClose")
    }
    func rightWillOpen() {
        print("SlideMenuControllerDelegate: rightWillOpen")
    }
    func rightDidOpen() {
        print("SlideMenuControllerDelegate: rightDidOpen")
    }
    func rightWillClose() {
        print("SlideMenuControllerDelegate: rightWillClose")
    }
    func rightDidClose() {
        print("SlideMenuControllerDelegate: rightDidClose")
    }
}
