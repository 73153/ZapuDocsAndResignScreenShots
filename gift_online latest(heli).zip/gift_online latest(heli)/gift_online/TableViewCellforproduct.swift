//
//  TableViewCellforproduct.swift
//  Delicious
//
//  Created by nilomi on 2/14/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

import UIKit

class TableViewCellforproduct: UITableViewCell {
    @IBOutlet weak var lbl_name: UILabel!
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    var  arydata = [product_details]()
    
    @IBOutlet var lbl_quantity: UILabel!
    
    
    @IBOutlet var btn_plus: UIButton!
    @IBOutlet var btn_minus: UIButton!
    @IBOutlet var imageview: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
 
    func DataBaseOperation() {
                
           let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent("bakerydb")
        print("doc path\(fileURL)")
    }

}
