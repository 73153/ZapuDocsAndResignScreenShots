//
//  CollectionCell.swift
//  Delicious
//
//  Created by heli on 2/15/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

import UIKit

class CollectionCell: UICollectionViewCell {
    @IBOutlet var imageView: UIImageView!
    
    @IBOutlet var label: UILabel!
}
