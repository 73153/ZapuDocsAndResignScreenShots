//
//  ProductTableViewController.swift
//  gift_online
//
//  Created by heli on 2/8/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

import UIKit

class ProductTableViewController: UITableViewController {
    
    //
    // MARK: - Data
    //
    
    
    struct Section {
        var name: String!
        var items: [String]!
        var collapsed: Bool!
        
        init(name: String, items: [String], collapsed: Bool = false) {
            self.name = name
            self.items = items
            self.collapsed = collapsed
        }
    }
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    var sections = [Section]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Initialize the sections array
        // Here we have three sections: Mac, iPad, iPhone
        sections = [
            Section(name: "cake", items: ["chocolate", "strawberry", "pineapple", "vanilla","whiteforest"]),
            Section(name: "cupcake", items: ["chocolate",  "pineapple", "vanilla"]),
            Section(name: "cookies", items: ["chocolate", "mixfruit", "gems"]),
            Section(name: "pastry", items: ["chocolate", "strawberry", "pineapple", "vanilla"]),
            Section(name: "puff", items: ["vegetable", "paneer", "cheese", "italian" ,"mexican"]),
            Section(name: "bread", items: ["breadslice", "wheatbreadslice", "bhajipavbread", "vadapavbread" ,"fruitbread"])
        ]
        
        
        self.setNavigationBarItem()
    }
    
    func setNavigationBarItem() {
        self.navigationController?.navigationBar.titleTextAttributes =
            [NSForegroundColorAttributeName: UIColor.blue]
        self.addLeftBarButtonWithImage((UIImage(named:"menu_icon")?.withRenderingMode(.alwaysOriginal))!)
        self.addRightBarButtonWithImage((UIImage(named:"search")?.withRenderingMode(.alwaysOriginal))!)
        self.slideMenuController()?.removeLeftGestures()
        self.slideMenuController()?.removeRightGestures()
        self.slideMenuController()?.addLeftGestures()
        self.slideMenuController()?.addRightGestures()
    }
    
    //
    // MARK: - Table view delegate
    //
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section {
        case 0:  return "Manufacture"
        case 1:  return "Products"
        default: return ""
        }
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 1
        }
        
        // For section 1, the total count is items count plus the number of headers
        var count = sections.count
        
        for section in sections {
            count += section.items.count
        }
        
        return count
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if (indexPath as NSIndexPath).section == 0 {
            return tableView.rowHeight
        }
        
        // Calculate the real section index and row index
        let section = getSectionIndex((indexPath as NSIndexPath).row)
        let row = getRowIndex((indexPath as NSIndexPath).row)
        
        // Header has fixed height
        if row == 0 {
            return 50.0
        }
        
        return sections[section].collapsed! ? 0 : 44.0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if (indexPath as NSIndexPath).section == 0 {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "header") as UITableViewCell!
            cell?.frame.size.height=20
            cell?.textLabel?.text = "Menu"
            return cell!
        }
        
        // Calculate the real section index and row index
        let section = getSectionIndex((indexPath as NSIndexPath).row)
        let row = getRowIndex((indexPath as NSIndexPath).row)
        
        if row == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "header") as! HeaderCell
            cell.titleLabel.text = sections[section].name
            cell.toggleButton.tag = section
            cell.toggleButton.setTitle(sections[section].collapsed! ? "+" : "-", for: UIControlState())
            cell.toggleButton.addTarget(self, action: #selector(ProductTableViewController.toggleCollapse), for: .touchUpInside)
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as UITableViewCell!
            cell?.textLabel?.text = sections[section].items[row - 1]
            print(sections[section].items[row - 1])
            return cell!
        }
    }
    
    override  public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let section = getSectionIndex((indexPath as NSIndexPath).row)
        let row = getRowIndex((indexPath as NSIndexPath).row)
        print(sections[section].name)
        print(sections[section].items[row - 1])
        appDelegate.category = sections[section].name
        appDelegate.filter = sections[section].items[row - 1]
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        
        let objSomeViewController = storyBoard.instantiateViewController(withIdentifier: "TableViewController") as! TableViewController
        
        self.navigationController?.pushViewController(objSomeViewController, animated: true)
    }
    
    //
    // MARK: - Event Handlers
    //
    func toggleCollapse(_ sender: UIButton) {
        let section = sender.tag
        let collapsed = sections[section].collapsed
        
        // Toggle collapse
        sections[section].collapsed = !collapsed!
        
        let indices = getHeaderIndices()
        
        let start = indices[section]
        let end = start + sections[section].items.count
        
        tableView.beginUpdates()
        for i in start ..< end + 1 {
            tableView.reloadRows(at: [IndexPath(row: i, section: 1)], with: .automatic)
        }
        tableView.endUpdates()
    }
    
    //
    // MARK: - Helper Functions
    //
    func getSectionIndex(_ row: NSInteger) -> Int {
        let indices = getHeaderIndices()
        
        for i in 0..<indices.count {
            if i == indices.count - 1 || row < indices[i + 1] {
                return i
            }
        }
        
        return -1
    }
    
    func getRowIndex(_ row: NSInteger) -> Int {
        var index = row
        let indices = getHeaderIndices()
        
        for i in 0..<indices.count {
            if i == indices.count - 1 || row < indices[i + 1] {
                index -= indices[i]
                break
            }
        }
        
        return index
    }
    
    func getHeaderIndices() -> [Int] {
        var index = 0
        var indices: [Int] = []
        
        for section in sections {
            indices.append(index)
            index += section.items.count + 1
        }
        
        return indices
    }
    
}



extension ProductTableViewController : SlideMenuControllerDelegate {
    func leftWillOpen() {
        print("SlideMenuControllerDelegate: leftWillOpen")
    }
    func leftDidOpen() {
        print("SlideMenuControllerDelegate: leftDidOpen")
    }
    func leftWillClose() {
        print("SlideMenuControllerDelegate: leftWillClose")
    }
    func leftDidClose() {
        print("SlideMenuControllerDelegate: leftDidClose")
    }
    func rightWillOpen() {
        print("SlideMenuControllerDelegate: rightWillOpen")
    }
    func rightDidOpen() {
        print("SlideMenuControllerDelegate: rightDidOpen")
    }
    func rightWillClose() {
        print("SlideMenuControllerDelegate: rightWillClose")
    }
    func rightDidClose() {
        print("SlideMenuControllerDelegate: rightDidClose")
    }
}
