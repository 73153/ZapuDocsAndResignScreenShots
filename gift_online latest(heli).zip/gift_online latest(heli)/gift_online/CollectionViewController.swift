//
//  CollectionViewController.swift
//  MultipleImageSelectionCollectionView
//
//  Created by heli on 1/18/17.
//  Copyright © 2017 com.zaptechsolution. All rights reserved.
//

import UIKit

class CollectionViewController: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate
 {

//    var Places: [UIImage] = [
//        UIImage(named: "Bulova-watches")!,
//        UIImage(named: "fastrack-watches")!,
//        UIImage(named: "Longines-watches")!,
//        UIImage(named: "watches")!,
//        UIImage(named: "6")!,
//       
//    ]
//    
    var Places = [product_details]()
    var selectedCell = [product_details]()
    
    @IBOutlet var collectionview: UICollectionView!
    @IBAction func btnShow(_ sender: AnyObject) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        
        let objSomeViewController = storyBoard.instantiateViewController(withIdentifier: "MultipleSelectionCollVC") as! MultipleSelectionCollVC
        objSomeViewController.displayArry=selectedCell
        self.navigationController?.pushViewController(objSomeViewController, animated: true)
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    let reuseIdentifier = "Cell2"
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return Places.count
    }
    
    // make a cell for each cell index path
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        // get a reference to our storyboard cell
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath as IndexPath) as! CollectionViewCell
        let task = Places[indexPath.row]
         cell.imgview.image = UIImage(named:task.image)!
        cell.product_name.text = task.product_name
        cell.product_type.text = task.type
        cell.price.text = task.price
       // cell.textLabel?.text = task.product_name
        
       // = Places[indexPath.item]
        
        
        cell.backgroundColor = UIColor.init(red: 135, green: 206, blue: 250, alpha: 1)
        return cell
    }
    // MARK: - UICollectionViewDelegate protocol
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = collectionView.cellForItem(at: indexPath)
        if cell?.isSelected == true {
           // cell?.backgroundColor = UIColor.lightGray
            selectedCell = [Places[indexPath.row]]
            
           // selectedCell.add(Places[indexPath.row])
        }
        
         }
    

}
