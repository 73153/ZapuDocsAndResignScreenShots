//
//  PaymentViewController.swift
//  Delicious
//
//  Created by heli on 2/16/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

import UIKit

class PaymentViewController: UIViewController {

    @IBOutlet var txtcardnumber: UITextField!
    
    @IBOutlet var txtCVVnumber: UITextField!
    @IBAction func btnMonthPressed(_ sender: AnyObject) {
    }
    @IBAction func btnYearPressed(_ sender: AnyObject) {
    }
    @IBOutlet var txtcardname: UITextField!
    
    @IBAction func btnCardsave(_ sender: AnyObject) {
    }
    
    @IBOutlet var btnCardsave: UIButton!
    
    
    @IBAction func btnProceed(_ sender: AnyObject) {
    }
    @IBAction func btncancel(_ sender: AnyObject) {
    }
    
    @IBAction func btnDone(_ sender: AnyObject) {
    }
    @IBOutlet var pickerview: UIPickerView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
