//
//  OrderCollectionViewCell.swift
//  Delicious
//
//  Created by heli on 2/16/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

import UIKit

class OrderCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var imageview: UIImageView!
    @IBOutlet var label: UILabel!
}
