//
//  MyMenuTableViewController.swift
//  SwiftSideMenu
//
//  Created by Evgeny Nazarov on 29.09.14.
//  Copyright (c) 2014 Evgeny Nazarov. All rights reserved.
//

import UIKit

class MyMenuTableViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    @IBOutlet weak var tableView: UITableView?
    var AryVCnames:[String] = ["Menu","Product","Near By","Category","Wishlist","Logout"]
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    let blackcolor = UIColor(red: 16/255.0, green: 27/255.0, blue: 57/255.0, alpha: 1.0)
    let objViewControllerMain = Orders_Wishlist_Vc()
      var selectedMenuItem : Int = 7
    // Mark : Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
      //  self.arypictures += [UIImage(named: "all_ques_icon")!, UIImage(named: "fav_ques_icon")!]
        
        view.backgroundColor = blackcolor
        tableView?.backgroundColor = blackcolor
        // Customize apperance of table view
        tableView?.contentInset = UIEdgeInsetsMake(0, 0, 0, 0) //
        //tableView?.separatorStyle = .none
         tableView?.separatorStyle = .singleLine
        tableView?.backgroundColor = UIColor.clear
        tableView?.scrollsToTop = false
        // Preserve selection between presentations
        
        self.tableView?.delegate = self
        self.tableView?.dataSource = self
        _ = IndexPath(row: 0, section: 0)
        self.tableView?.reloadData()
        let headerView = UIView(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(200), height: CGFloat(180)))
        let imageView = UIImageView(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(280), height: CGFloat(180)))
        headerView.addSubview(imageView)
        let image = UIImage(named: "header")!
        imageView.image = image
        self.tableView?.tableHeaderView = headerView
        //Edit
        let indexPath = IndexPath(row: 0, section: 0)
        self.tableView?.selectRow(at: indexPath, animated: true, scrollPosition: UITableViewScrollPosition.none)
       // imagepress = true
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        NotificationCenter.default.addObserver(forName: .UIContentSizeCategoryDidChange, object: .none, queue: OperationQueue.main) {
            [weak self] _ in
            self?.tableView?.reloadData()
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
    }
    // MARK: - Table view Method
    
    private func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        return AryVCnames.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell :sidebarcell = tableView.dequeueReusableCell(withIdentifier: "CustomCell") as! sidebarcell
        
        let Currentrow: Int = indexPath.row
        
       
            cell.lbl_sidebar.textColor = UIColor.white
                       cell.img_sidebar.image = UIImage(named:"category-active")
           
        
        cell.lbl_sidebar.font = UIFont.preferredFont(forTextStyle: UIFontTextStyle.headline)
        cell.backgroundColor = blackcolor
        cell.lbl_sidebar.text = AryVCnames[indexPath.row]
        cell.selectionStyle = .none
        

        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50.0
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
         print("did select row: \(indexPath.row)")
        
        let Currentrow: Int = indexPath.row
        let cell : sidebarcell = self.tableView?.cellForRow(at: indexPath) as! sidebarcell
        cell.lbl_sidebar.textColor = UIColor.white
      
            let cell5 : sidebarcell = self.tableView?.cellForRow(at: indexPath) as! sidebarcell
            cell5.lbl_sidebar.textColor = UIColor(red: 0x8C, green: 0xC6, blue: 0x26)
            cell5.img_sidebar.image = UIImage(named:"category-active")
        
        let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main",bundle: nil)
        
        var destViewController : UIViewController
         tableView.reloadData()
         destViewController = mainStoryboard.instantiateViewController(withIdentifier: "Orders_Wishlist_Vc")
        switch (indexPath.row) {
          
        case 0:
//            "Menu"
            destViewController = mainStoryboard.instantiateViewController(withIdentifier: "Orders_Wishlist_Vc") as! Orders_Wishlist_Vc
            let cell1 : sidebarcell = self.tableView?.cellForRow(at: indexPath) as! sidebarcell
            cell1.lbl_sidebar.textColor = UIColor(red: 0x8C, green: 0xC6, blue: 0x26)
            
            selectedMenuItem = 0
           break
            
        case 1:
//            "Product"
            destViewController = mainStoryboard.instantiateViewController(withIdentifier: "ProductTableViewController") as! ProductTableViewController
            let cell1 : sidebarcell = self.tableView?.cellForRow(at: indexPath) as! sidebarcell
            cell1.lbl_sidebar.textColor = UIColor(red: 0x8C, green: 0xC6, blue: 0x26)
            selectedMenuItem = 1
            break
            
        case 2:
//            ,"Near By"
            destViewController = mainStoryboard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
            let cell1 : sidebarcell = self.tableView?.cellForRow(at: indexPath) as! sidebarcell
            cell1.lbl_sidebar.textColor = UIColor(red: 0x8C, green: 0xC6, blue: 0x26)
            selectedMenuItem = 2
            break

            
                 case 3:
//            ,"Category"
                    destViewController = mainStoryboard.instantiateViewController(withIdentifier: "Orders_Wishlist_Vc") as! Orders_Wishlist_Vc
                    
                    let cell1 : sidebarcell = self.tableView?.cellForRow(at: indexPath) as! sidebarcell
                    cell1.lbl_sidebar.textColor = UIColor(red: 0x8C, green: 0xC6, blue: 0x26)
                    selectedMenuItem = 0
            break

            case 4: break
//            ,"Wishlist"
//            destViewController = mainStoryboard.instantiateViewController(withIdentifier: "CategoriesViewController") as! CategoriesViewController
//            
//            let cell1 : sidebarcell = self.tableView?.cellForRow(at: indexPath) as! sidebarcell
//            cell1.lbl_sidebar.textColor = UIColor(red: 0x8C, green: 0xC6, blue: 0x26)
//            selectedMenuItem = 4
        //    break
        case 5:
//            ,"Logout"
            destViewController = mainStoryboard.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
            let cell1 : sidebarcell = self.tableView?.cellForRow(at: indexPath) as! sidebarcell
            cell1.lbl_sidebar.textColor = UIColor(red: 0x8C, green: 0xC6, blue: 0x26)
            selectedMenuItem = 5
            
            break
            
       
            
        default:
            destViewController = mainStoryboard.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
            
            let cell1 : sidebarcell = self.tableView?.cellForRow(at: indexPath) as! sidebarcell
            cell1.lbl_sidebar.textColor = UIColor(red: 0x8C, green: 0xC6, blue: 0x26)
            
            selectedMenuItem = 5
            break
        }
        
        
        
        let nvc: UINavigationController = UINavigationController(rootViewController: destViewController)
        
//        nvc.navigationBar.barTintColor = UIColor(red: CGFloat(16.0 / 255.0), green: CGFloat(27.0 / 255.0), blue: CGFloat(57.0 / 255.0), alpha: CGFloat(0.0 / 255.0))
        
          nvc.navigationBar.barTintColor = UIColor.red
       
        self.slideMenuController()?.changeMainViewController(nvc, close: true)
        
    }
}
