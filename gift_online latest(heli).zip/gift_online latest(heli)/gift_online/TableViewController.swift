//
//  TableViewController.swift
//  MultipleImageSelectionCollectionView
//
//  Created by heli on 1/18/17.
//  Copyright © 2017 com.zaptechsolution. All rights reserved.
//

import UIKit

class TableViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    var x=0
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    //    var Places: [UIImage] = [
    //        UIImage(named: "watches")!,
    //        UIImage(named: "2")!,
    //        UIImage(named: "3")!,
    //        UIImage(named: "4")!,
    //        UIImage(named: "5")!,
    //        UIImage(named: "6")!,
    //        UIImage(named: "7")!,
    //        UIImage(named: "8")!,
    //        UIImage(named: "9")!
    //
    //    ]
    var  arydata = [product_details]()
    var selectedCell = [product_details]()
    @IBOutlet var tblView: UITableView!
    //        @IBAction func Selectedrows(_ sender: AnyObject) {
    //            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
    //
    //            let objSomeViewController = storyBoard.instantiateViewController(withIdentifier: "MultipleselectionTableVC") as! MultipleselectionTableVC
    //            objSomeViewController.displayArry=selectedCell as NSArray
    //            self.navigationController?.pushViewController(objSomeViewController, animated: true)
    //
    //
    //        }
    let cellReuseIdentifier = "Cell1"
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.navigationItem.title=appDelegate.filter
        tblView.register(UITableViewCell.self, forCellReuseIdentifier: cellReuseIdentifier)
        tblView.backgroundColor = UIColor(patternImage: UIImage(named: "bg")!)
        GetDataFromDataBase()
        let rightAddBarButtonItem:UIBarButtonItem = UIBarButtonItem(title: "Next", style: UIBarButtonItemStyle.plain, target: self, action: #selector(TableViewController.addTapped))
        
        
        let image = UIImage(named: "header")! as UIImage
        
        self.navigationController?.navigationBar.setBackgroundImage(image,
                                                                    for: .default)
        self.navigationItem.setRightBarButtonItems([rightAddBarButtonItem], animated: true)
        let longGesture = UILongPressGestureRecognizer(target: self, action: #selector(TableViewController.longTap))
        // [[UINavigationBar appearance] setTintColor:[UIColor redColor]];
        tblView.addGestureRecognizer(longGesture)
    }
    
    func longTap(sender : UIGestureRecognizer){
        print("Long tap")
        if sender.state == .ended {
            print("UIGestureRecognizerStateEnded")
            //Do Whatever You want on End of Gesture
            if x==0 {
                tblView.allowsMultipleSelectionDuringEditing = true
                tblView.setEditing(true, animated: false)
                x=1;
            }
            else {
                tblView.allowsMultipleSelectionDuringEditing = false
                tblView.setEditing(false, animated: false)
                selectedCell = [product_details]()
                x=0;
            }
            
        }
        else if sender.state == .began {
            print("UIGestureRecognizerStateBegan.")
            //Do Whatever You want on Began of Gesture
        }
    }
    
    
    func addTapped (sender:UIButton) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        
        let objSomeViewController = storyBoard.instantiateViewController(withIdentifier: "CollectionViewController") as! CollectionViewController
        objSomeViewController.Places = (selectedCell as NSArray) as! [product_details]
        self.navigationController?.pushViewController(objSomeViewController, animated: true)
        
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arydata.count
    }
    
    // create a cell for each table view row
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // create a new cell if needed or reuse an old one
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellproduct",
                                                 for: indexPath) as! TableViewCellforproduct
        
        
        
        let task = arydata[indexPath.row]
        var  arycheck = [order_details]()
        arycheck = order_details.rows(filter:"product_name = '\(task.product_name)'",order:"order_id ASC") as! [order_details]
        
        if(arycheck.count > 0){
        let taskforqnty = arycheck[0]
        let xNSNumber = taskforqnty.product_quantity as NSNumber
        cell.lbl_quantity.text = xNSNumber.stringValue
        }
        cell.lbl_name.text = task.product_name
        cell.imageview.image = UIImage(named:task.image)!
        cell.backgroundColor = UIColor(patternImage: UIImage(named: "bg")!)
        cell.btn_plus.tag = indexPath.row + 1300
        cell.btn_plus.titleLabel?.text = "Plus"
        cell.btn_plus.addTarget(self, action: #selector(self.DataBaseOperation), for: .touchUpInside)
        
        cell.btn_minus.tag = indexPath.row + 2300
        cell.btn_minus.titleLabel?.text = "Minus"
        cell.btn_minus.addTarget(self, action: #selector(self.DataBaseOperation), for: .touchUpInside)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            arydata.remove(at: indexPath.row)
            tblView.deleteRows(at: [indexPath], with: .fade)
        }
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        selectedCell = [arydata[indexPath.row]]
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        // selectedCell.remove(at: arydata[indexPath.row])
        //     selectedCell  = [product_details]()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    func DataBaseOperation(sender : UIButton) {
        
        let btnReoder: UIButton? = (sender as? UIButton)
        let btnTag: Int
        if (btnReoder?.titleLabel?.text == "Plus"){
            btnTag = (btnReoder?.tag)! - 1300
        }
        else{
            btnTag = (btnReoder?.tag)! - 2300
        }
        let dboptask = arydata[btnTag]
        let str = dboptask.product_name
        let newtask = order_details()
        var  arycheck = [order_details]()
        var minuscheck : Bool = true
        arycheck = order_details.rows(filter:"product_name = '\(str)'",order:"order_id ASC") as! [order_details]
        if(arycheck.count > 0){
        
        }
        if ((arycheck.isEmpty || arycheck[0].product_quantity == 0) && btnReoder?.titleLabel?.text == "Minus"){
            minuscheck = false
        }
        else if (arycheck.count > 0 && btnReoder?.titleLabel?.text == "Plus"){
            let new1 = arycheck[0]
            let strquntity = new1.product_quantity
            let strid = new1.order_id
            newtask.order_id =  strid
            newtask.product_quantity = strquntity + 1
        }
        else if (arycheck.count > 0 && btnReoder?.titleLabel?.text == "Minus"){
            let new1 = arycheck[0]
            let strquntity = new1.product_quantity
            let strid = new1.order_id
            newtask.order_id =  strid
            newtask.product_quantity = strquntity - 1
        }
        else if (arycheck.isEmpty && btnReoder?.titleLabel?.text == "Plus") {
            newtask.product_quantity = 1
        }
        if(minuscheck){
        newtask.product_name = dboptask.product_name
        newtask.product_price = dboptask.price
        newtask.deliveryadddress = "qqq"
        newtask.phn_no = 123
        if newtask.save() != 0 {
            print("success")
            tblView.reloadData()
            
        }
        }
        let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent("bakerydb")
        print("doc path\(fileURL)")
    }
    func GetDataFromDataBase() {
        
        let db = SQLiteDB.sharedInstance
        
        //        arydata = product_details.rows(order:"product_id ASC") as! [product_details]
        arydata = product_details.rows(filter:"subtype = '\(appDelegate.filter)'",filter1:"categories= '\(appDelegate.category)'",order:"product_id ASC") as! [product_details]
        
        let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent("bakerydb")
        print("doc path\(fileURL)")
    }
    
}
