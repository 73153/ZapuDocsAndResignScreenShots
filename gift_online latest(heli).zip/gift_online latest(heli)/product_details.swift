//
//  product_details.swift
//  Delicious
//
//  Created by nilomi on 2/10/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

#if os(iOS)
    import UIKit
#else
    import AppKit
#endif


class product_details:SQLTable {
    var product_id = -1
    var product_name = ""
    var price = ""
    var type = ""
    var image = ""
    var categories = ""
    
}
