//
//  ActionViewController.h
//  ReadItAction
//
//  Created by ami on 10/26/16.
//  Copyright © 2016 com.zaptechsolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ActionViewController : UIViewController

@end
